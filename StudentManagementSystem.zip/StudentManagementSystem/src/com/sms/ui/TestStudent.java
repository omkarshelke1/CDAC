package com.sms.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.sms.service.SMSService;
import com.sms.service.SMSServiceImpl;

public class TestStudent {
	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in))
		{
			SMSService service = new SMSServiceImpl();
			boolean exit = true;
			int ch;
			while(!false) {
				System.out.println("Enter choice: \n1.Admit Student \n2.Cancel Admission \n3.Search student by email \n4.List all Student \n5.List Students by course \n6.Sort by email \n0.Exit");
				ch = sc.nextInt();
				try {
					switch(ch)
					{
					case 1:
						System.out.println("Enter Student details: name,email,marks,course,admDate");
						service.admitStudent(sc.next(), sc.next(), sc.nextInt(), sc.next(),sc.next());
						break;
					case 2:
						System.out.println("Enter email:");
						service.cancelAdmission(sc.next());
						break;
					case 3:
						System.out.println("Enter email:");
						service.displayStudentByEmail(sc.next());
						break;
					case 4:
						service.displayStudents();
						break;
					case 5:
						System.out.println("Enter course name:");
						service.listStudentsByCourse(sc.next());
						break;
					case 6:
						service.sortByEmail();
						break;
					case 0:
						exit = false;
						break;
					}
				}
				catch(Exception e)
				{
					sc.nextLine(); //read all pending inputs from scanner
					e.printStackTrace();
				}
				
		}
	}
	}
}
