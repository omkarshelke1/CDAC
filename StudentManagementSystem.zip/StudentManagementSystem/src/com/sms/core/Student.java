package com.sms.core;

import java.time.LocalDate;

public class Student implements Comparable<Student> {
	private int id;
	private String name;
	private String email;
	private int marks;
	private Courses course;
	private LocalDate admDate;
	private static int idCounter;
	
	public Student(String email) {
		this.email = email;
	}
	public Student(String name, String email, int marks, Courses course, LocalDate admDate) {
		this.id = ++idCounter;
		this.name = name;
		this.email = email;
		this.marks = marks;
		this.course = course;
		this.admDate = admDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Courses getCourse() {
		return course;
	}
	public void setCourse(Courses course) {
		this.course = course;
	}
	public LocalDate getAdmDate() {
		return admDate;
	}
	public void setAdmDate(LocalDate admDate) {
		this.admDate = admDate;
	}
	public static int getIdCounter() {
		return idCounter;
	}
	public static void setIdCounter(int idCounter) {
		Student.idCounter = idCounter;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", email=" + email + ", marks=" + marks + ", course=" + course
				+ ", admDate=" + admDate + "]";
	}
	

	@Override
	public boolean equals (Object o) {
		if(o instanceof Student) {
			Student student = (Student)o;
			return this.email.equals(student.email);
		}
		return false;
	}
	
	@Override
	public int compareTo(Student anotherStudent)
	{
		return this.email.compareTo(anotherStudent.email);
	}
	
}
