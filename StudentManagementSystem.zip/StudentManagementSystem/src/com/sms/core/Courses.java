package com.sms.core;

public enum Courses {
	CORE_JAVA(75), DBT(70), PYTHON(85) , MERN(70), WEB_JAVA(90),DEV_OPS(65);
	private int minMarks;
	Courses(int minMarks)
	{
		this.minMarks = minMarks;
	}
	public int getMinMarks() {
		return minMarks;
	}
	public void setMinMarks(int minMarks) {
		this.minMarks = minMarks;
	}
	
	@Override
	public String toString() {
		return name()+"minMarks ="+this.minMarks;
	}
}
