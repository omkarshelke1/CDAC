package com.sms.service;

import java.time.LocalDate;
import java.util.List;

import com.sms.core.Courses;
import com.sms.core.Student;
import com.sms.exception.StudentException;

public class SMSValidations {
	public static Student validateStudent(String name, String email, int marks, String course, String admDate,List<Student> list) throws StudentException
	{
		validateEmail(email,list);
		Courses validCourse = validateMarks(marks,course);
		return new Student(name,email,marks,validCourse,LocalDate.parse(admDate));
		
	}
	
	public static Courses validateMarks(int marks, String course) throws StudentException,IllegalArgumentException{
		Courses courses = Courses.valueOf(course.toUpperCase());
		if(courses.getMinMarks() > marks)
			throw new StudentException("Marks is less to take admission in this course !!!");
		return courses;
		
	}

	public static void validateEmail(String email,List<Student> list) throws StudentException
	{
		Student newStudent = new Student(email);
		if(list.contains(newStudent))
			throw new StudentException("Email is dupliacte !!!"); 
	}
}
