package com.sms.service;

import static com.sms.service.SMSValidations.validateStudent;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.sms.core.Courses;
import com.sms.core.Student;
import com.sms.exception.StudentException;

public class SMSServiceImpl implements SMSService{
	private List<Student> list;
	public SMSServiceImpl(){
		this.list = new ArrayList<>(100);
		list.add(new Student("Rahul Sharma", "rahul.sharma@example.in", 85, Courses.CORE_JAVA, LocalDate.of(2023, 7, 15)));
		list.add(new Student("Priya Iyer", "priya.iyer@example.in", 92, Courses.DBT, LocalDate.of(2022, 8, 10)));
		list.add(new Student("Amit Patel", "amit.patel@example.in", 88, Courses.PYTHON, LocalDate.of(2024, 1, 5)));
		list.add(new Student("Neha Reddy", "neha.reddy@example.in", 92, Courses.WEB_JAVA, LocalDate.of(2023, 6, 20)));
		list.add(new Student("Arjun Singh", "arjun.singh@example.in", 68, Courses.DEV_OPS, LocalDate.of(2022, 9, 12)));
	}
	
	@Override
	public void displayStudents() {
		for(Student s : list) {
			System.out.println(s);
		}
	}

	@Override
	public void admitStudent(String name, String email, int marks, String course, String admDate)
			throws StudentException {
			Student s = validateStudent(name,email,marks,course,admDate,list);
			list.add(s);
		
	}

	@Override
	public void cancelAdmission(String email) throws StudentException{
		Student s = new Student(email);
		int index = list.indexOf(s);
		if(index == -1)
			throw new StudentException("Email not found!!!");
		list.remove(index);
		
	}
	
	@Override 
	public void displayStudentByEmail(String email) throws StudentException
	{
		int found = 0;
		for(Student s : list)
		{
			if(s.getEmail().equals(email)) {
				found = 1;
				System.out.println(s);
			}
				
		}
		if(found == 0) {
			throw new StudentException("Student not found !!!");
		}
		 
	}

	@Override
	public void sortByEmail() {
		Collections.sort(list);
		
	}

	@Override
	public void listStudentsByCourse(String course) throws StudentException{
		Courses newCourse = Courses.valueOf(course);
		int found = 0;
		for(Student s : list)
		{
			if(s.getCourse().equals(newCourse))
			{
				found = 1;
				System.out.println(s);
			}
		}
		if(found == 0)
		{
			throw new StudentException("No student found with such course !!!");
		}
		
	}
}
