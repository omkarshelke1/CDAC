package com.sms.service;

import java.time.LocalDate;

import com.sms.core.Courses;
import com.sms.exception.StudentException;

public interface SMSService {
	void admitStudent(String name, String email, int marks, String course, String admDate) throws StudentException;
	void displayStudents();
	void cancelAdmission(String email) throws StudentException;
	void displayStudentByEmail(String email) throws StudentException;
	void sortByEmail();
	void listStudentsByCourse(String course) throws StudentException;
	
}
