package com.mms.core;

public enum MobileType {
	ANDROID,IOS
}
