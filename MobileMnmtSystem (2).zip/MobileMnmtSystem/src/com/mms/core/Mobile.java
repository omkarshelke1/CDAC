package com.mms.core;

import java.time.LocalDate;

public class Mobile implements Comparable<Mobile>{
	private int id;
	private String brand;
	private String model;
	private double price ;
	private int ram;
	private int storage;
	private boolean isAvl;
	private MobileType type;
	private LocalDate launchDate;
	private static int idCounter = 1;
	public Mobile(String brand, String model, double price, int ram, int storage, boolean isAvl,
			MobileType type,LocalDate launchDate) {
		this.id = idCounter++;
		this.brand = brand;
		this.model = model;
		this.price = price;
		this.ram = ram;
		this.storage = storage;
		this.isAvl = isAvl;
		this.type = type;
		this.launchDate = launchDate;
	}
	public LocalDate getLaunchDate() {
		return launchDate;
	}
	public void setLaunchDate(LocalDate launchDate) {
		this.launchDate = launchDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getRam() {
		return ram;
	}
	public void setRam(int ram) {
		this.ram = ram;
	}
	public int getStorage() {
		return storage;
	}
	public void setStorage(int storage) {
		this.storage = storage;
	}
	public boolean isAvl() {
		return isAvl;
	}
	public void setAvl(boolean isAvl) {
		this.isAvl = isAvl;
	}
	public MobileType getType() {
		return type;
	}
	public void setType(MobileType type) {
		this.type = type;
	}
	public static int getIdCounter() {
		return idCounter;
	}
	public static void setIdCounter(int idCounter) {
		Mobile.idCounter = idCounter;
	}
	
	@Override
	public String toString() {
		return "Mobile [id=" + id + ", brand=" + brand + ", model=" + model + ", price=" + price + ", ram=" + ram
				+ ", storage=" + storage + ", isAvl=" + isAvl + ", type=" + type + ", launchDate=" + launchDate + "]";
	}
	@Override
	public int compareTo(Mobile o) {
		
		return ((Integer)this.getId()).compareTo(o.getId());
	}
	
	@Override
	public boolean equals(Object o)
	{
		if(o instanceof Mobile)
		{
			Mobile m = (Mobile)o;
			return this.id == m.id;
		}
		return false;
	}
	
	
	
	
	
}
