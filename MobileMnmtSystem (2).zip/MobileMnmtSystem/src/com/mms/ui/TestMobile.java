package com.mms.ui;

import java.util.Scanner;

import com.mms.service.MobileService;
import com.mms.service.MobileServiceImpl;

public class TestMobile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch = 1;
		Scanner sc = new Scanner(System.in);
		MobileService mobileService = new MobileServiceImpl();
		
		do {
			try {
				System.out.println("\n1.Add new Mobile \n2.Display all"
						+ "\n3.Sort by id \n4.Most Expensive Smartphone"
						+ "\n5.Remove not available \n6.Update price"
						+ "\n7.Sort by price in descending \n8.Sort by storage"
						+ "\n9.Sort by brand \n10.Search by brand "
						+ "\n11.Sort By latest Date \n12.Update date by id\n0.Exit");
				System.out.println("Enter choice:");
				ch = sc.nextInt();
				
				switch(ch)
				{
				case 1:
					System.out.println("Enter brand,model,price,ram,storage,availability,type(android/ios),launch date(yyyy-mm-dd)");
					String brand = sc.next();
					String model = sc.next();
					double price = sc.nextDouble();
					int ram = sc.nextInt();
					int storage = sc.nextInt();
					boolean isAvl = sc.nextBoolean();
					String type = sc.next();
					String date = sc.next();
					mobileService.addMobile(brand,model,price,ram,storage,isAvl,type,date);
					System.out.println("Mobile added successfully !!!");
					
					break;
				case 2:
					mobileService.displayAllMobiles();
					break;
				case 3:
					mobileService.sortById();
					break;
				case 4:
					mobileService.mostExpensive();
					break;
				case 5:
					mobileService.removeUnAvailable();
					break;
				case 6:
					System.out.println("Enter brand and price:");
					brand = sc.next();
					price = sc.nextDouble();
					mobileService.updatePrice(brand,price);
					break;
				case 7:
					mobileService.sortByPriceInDesc();
					break;
					
				case 8:
					mobileService.sortByStorage();
					break;
					
				case 9:
					mobileService.sortByBrand();
					break;
					
				case 10:
					System.out.println("Enter brand:");
					brand = sc.next();
					mobileService.searchByBrand(brand);
					break;
					
				case 11:
					mobileService.sortByLatestDate();
					break;
					
				case 12:
					System.out.println("Enter id:");
					int id = sc.nextInt();
					System.out.println("Enter new launch date(yyyy-mm-dd):");
					date = sc.next();
					mobileService.updateDateById(id,date);
					break;
					
				case 0:
					System.out.println("Thank You !!!!");
					break;
				default:
					System.out.println("Enter valid choice !!!");
					break;
				
				
				}
				
			}
			catch(Exception e)
			{
				System.out.println("Error:" + e.getMessage());
				sc.nextLine();
			}
		}while(ch != 0);
		
		sc.close();
	}

}
