package com.mms.service;

import java.time.LocalDate;

import com.mms.core.Mobile;
import com.mms.core.MobileType;
import com.mms.exception.MyException;

public class MobileValidation {
	public static Mobile validateAllInputs(String brand,String model,double price,int ram,int storage,boolean isAvl,String type,String date) throws MyException
	{
		validatePrice(price);
		validateRam(ram);
		validateStorage(storage);
		validateOS(type);
		validateBrand(brand);
		validateDate(date);
		Mobile mobile = new Mobile(brand,model,price,ram,storage,isAvl,MobileType.valueOf(type.toUpperCase()),LocalDate.parse(date));
		return mobile;
		
	}

	private static void validateDate(String date) throws MyException {
		LocalDate newDate = LocalDate.parse(date);
		if(newDate.isAfter(LocalDate.now()))
		{
			throw new MyException("Launch Date should be before the current date !!!");
		}
		
	}

	public static void validateRam(int ram) throws MyException {
		if(ram < 2 || ram > 24)
		{
			throw new MyException("Ram must be between 2-24 !!!");
		}
		
	}

	public static void validateOS(String type) throws MyException{
		// TODO Auto-generated method stub
		try {
			 MobileType.valueOf(type.toUpperCase());
		}
		catch(Exception e)
		{
			throw new MyException("Select valid OS type(android/ios) !!!");
		}
		
	}

	public static void validateBrand(String brand) throws MyException{
		// TODO Auto-generated method stub
		if(brand.length() < 2 || brand.length() > 30)
		{
			throw new MyException("Brand length must be between 2-30 !!!");
		}
		
	}

	public static void validateStorage(int storage) throws MyException{
		// TODO Auto-generated method stub
		if(storage < 32)
		{
			throw new MyException("Storage must be bigger than 32 !!!");
		}
		
	}

	public static void validatePrice(double price) throws MyException{
		// TODO Auto-generated method stub
		if(price < 0)
		{
			throw new MyException("Price should be greater than 0 !!!");
		}
		
	}
}
