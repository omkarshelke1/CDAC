package com.mms.service;

import static com.mms.service.MobileValidation.validateAllInputs;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.mms.core.Mobile;
import com.mms.core.MobileType;
import com.mms.exception.MyException;

public class MobileServiceImpl implements MobileService{
	List<Mobile> list = new ArrayList<Mobile>();
	
	{
	list.add(new Mobile("Apple", "iPhone 15", 79999.99, 6, 128, true,MobileType.IOS,LocalDate.parse("2021-12-08")));
    list.add(new Mobile("Apple", "iPhone 14", 69999.00, 6, 128, false, MobileType.IOS,LocalDate.parse("2024-11-08")));
    list.add(new Mobile("Samsung", "Galaxy S24", 74999.50, 8, 256, true, MobileType.ANDROID,LocalDate.parse("2023-10-04")));
    list.add(new Mobile("OnePlus", "11R", 42999.00, 8, 128, true, MobileType.ANDROID,LocalDate.parse("2021-05-10")));
    list.add(new Mobile("Xiaomi", "Redmi Note 13", 18999.00, 6, 128, true, MobileType.ANDROID,LocalDate.parse("2022-02-03")));
    list.add(new Mobile("Realme", "Narzo 70", 15999.00, 8, 128, false, MobileType.ANDROID,LocalDate.parse("2020-12-25")));
    list.add(new Mobile("Google", "Pixel 8", 84999.00, 8, 128, true, MobileType.ANDROID,LocalDate.parse("2025-01-08")));
    list.add(new Mobile("Apple", "iPhone SE", 49999.00, 4, 64, true, MobileType.IOS,LocalDate.parse("2024-06-16")));
    list.add(new Mobile("Samsung", "Galaxy A55", 30999.00, 8, 128, true, MobileType.ANDROID,LocalDate.parse("2024-12-11")));
    list.add(new Mobile("Apple", "iPhone 13", 61999.00, 6, 128, false, MobileType.IOS,LocalDate.parse("2022-09-02")));
	}
	
	@Override
	public void addMobile(String brand, String model, double price, int ram, int storage, boolean isAvl, String type,String date)
			throws MyException {
		// TODO Auto-generated method stub
		Mobile mobile = validateAllInputs(brand,model,price,ram,storage,isAvl,type,date);
		list.add(mobile);
		
	}

	@Override
	public void displayAllMobiles() {
		list.forEach(m->System.out.println(m));
		
	}

	@Override
	public void sortById() {
		Collections.sort(list);
		list.forEach(m->System.out.println(m));
		
	}

	@Override
	public void mostExpensive() throws MyException {
		Mobile mostExpensive = list.stream()
				.max((a,b)->((Double)a.getPrice()).compareTo(b.getPrice()))
				.orElseThrow(()-> new MyException("Most expensive not found !!!"));
		
		System.out.println("Most expensive mobile: "+mostExpensive);	
		
	}

	@Override
	public void removeUnAvailable() {
		list.removeIf(m-> m != null && !m.isAvl());
		System.out.println("Removed Successfully !!!");
		
	}

	@Override
	public void updatePrice(String brand, double price) throws MyException {
		try {
			list.stream()
			.filter(m->m.getBrand().equals(brand))
			.forEach(m->m.setPrice(price));
			
			System.out.println("Price updated successfully !!!");
		}
		catch(Exception e)
		{
			throw new MyException("Brand not found !!!");
		}
		
	}

	@Override
	public void sortByPriceInDesc() {
		list.stream()
		.sorted((a,b)->((Double)b.getPrice()).compareTo(a.getPrice()))
				.forEach(m->System.out.println(m));
		
	}

	@Override
	public void sortByStorage() {
		list.stream()
		.sorted((a,b)->((Integer)(a.getStorage())).compareTo(b.getStorage()))
				.forEach(m->System.out.println(m));
		
	}

	@Override
	public void sortByBrand() {
		list.stream()
		.sorted((a,b)->a.getBrand().compareTo(b.getBrand()))
		.forEach(m->System.out.println(m));
		
	}

	@Override
	public void searchByBrand(String brand) {
		list.stream()
		.filter(m->m.getBrand().equalsIgnoreCase(brand))
		.forEach(m->System.out.println(m));
		
	}

	@Override
	public void sortByLatestDate() {
		list.stream()
		.sorted((a,b)->b.getLaunchDate().compareTo(a.getLaunchDate()))
		.forEach(m->System.out.println(m));
		
	}

	@Override
	public void updateDateById(int id,String date) throws MyException{
		for(Mobile m:list)
		{
			if(m.getId() == id)
			{
				m.setLaunchDate(LocalDate.parse(date));
			}
		}
		
	}
	
	
	
	

}
