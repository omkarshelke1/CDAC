package com.mms.service;

import com.mms.exception.MyException;

public interface MobileService {
	void addMobile(String brand,String model,double price,int ram,int storage,boolean isAvl,String type,String date) throws MyException;

	void displayAllMobiles();

	void sortById();

	void mostExpensive() throws MyException;

	void removeUnAvailable();

	void updatePrice(String brand, double price) throws MyException ;

	void sortByPriceInDesc();

	void sortByStorage();

	void sortByBrand();

	void searchByBrand(String brand);

	void sortByLatestDate();

	void updateDateById(int id,String date) throws MyException;
}
