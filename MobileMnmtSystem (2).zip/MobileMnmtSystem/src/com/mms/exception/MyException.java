package com.mms.exception;

@SuppressWarnings("serial")
public class MyException extends Exception{
	public MyException(String msg)
	{
		super(msg);
	}
}
