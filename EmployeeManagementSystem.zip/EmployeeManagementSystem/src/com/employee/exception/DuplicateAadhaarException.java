package com.employee.exception;


@SuppressWarnings("serial")
public class DuplicateAadhaarException extends Exception{

	public DuplicateAadhaarException(String message) {
		super(message);
	}
}