package com.employee.exception;


@SuppressWarnings("serial")
public class InvalidAadhaarException extends Exception{

	public InvalidAadhaarException(String message) {
		super(message);
	}
}
