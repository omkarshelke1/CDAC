package com.employee.ui;

import java.util.Scanner;

import com.employee.exception.DuplicateAadhaarException;
import com.employee.exception.InvalidAadhaarException;
import com.employee.exception.InvalidPhoneNumberException;
import com.employee.service.EmployeeService;
import com.employee.service.EmployeeServiceImpl;

public class EmployeeMain {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeService service = new EmployeeServiceImpl();
        boolean exit = false;

        try {
        while (!exit) {
            System.out.println("\n========== EMPLOYEE MANAGEMENT SYSTEM ==========");
            System.out.println("1. Add Employee");
            System.out.println("2. Display All Employees");
            System.out.println("3. Display Employee Specific Actions");
            System.out.println("4. Delete Employee by ID");
            System.out.println("5. Search Employee by Aadhaar");
            System.out.println("6. Update Employee Phone Number");
            System.out.println("7. Display by Department");
            System.out.println("8. Sort Employees by Joining Date");
            System.out.println("9. Sort Employees by Name");
            System.out.println("10. Get Highest Paid Employee");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.println("Select Employee Type:");
                        System.out.println("1. Full Time Employee");
                        System.out.println("2. Part Time Employee");
                        int typeChoice = sc.nextInt();
                        sc.nextLine();

                        System.out.print("Enter Name: ");
                        String name = sc.nextLine();
                        
                        System.out.print("Enter Date of Joining (yyyy-MM-dd): ");
                        String doj = sc.nextLine();
                        
                        System.out.print("Enter Phone Number: ");
                        String phone = sc.nextLine();
                        
                        System.out.print("Enter Aadhaar Number (12 digits): ");
                        String aadhaar = sc.nextLine();
                        
                        System.out.print("Enter Department (IT, HR, SALES, FINANCE, etc): ");
                        String dept = sc.nextLine().toUpperCase();

                        String type = (typeChoice == 1) ? "FULLTIME" : "PARTTIME";

                        double monthlySalary = 0, bonus = 0, hourlyRate = 0;
                        int hoursWorked = 0;

                        if (type.equals("FULLTIME")) {
                            System.out.print("Enter Monthly Salary: ");
                            monthlySalary = sc.nextDouble();
                            System.out.print("Enter Performance Bonus: ");
                            bonus = sc.nextDouble();
                            // for the employees reprsenting the part-time-specific fields:
                            hourlyRate = 0;
                            hoursWorked = 0;
                        } else {
                            System.out.print("Enter Hourly Rate: ");
                            hourlyRate = sc.nextDouble();
                            System.out.print("Enter Hours Worked: ");
                            hoursWorked = sc.nextInt();
                            // for the employees reprsenting the full-time-specific fields:
                            monthlySalary = 0;
                            bonus = 0;
                        }

                        service.addEmployee(name, doj, phone, aadhaar, dept, type, monthlySalary, bonus, hourlyRate, hoursWorked);
                        break;

                    case 2:
                        service.displayallEmployee();
                        break;

                    case 3:
                        service.DisplayEmployeeSpecificActions();
                        break;

                    case 4:
                        System.out.print("Enter Employee ID to delete: ");
                        int delId = sc.nextInt();
                        service.deleteEmployeeById(delId);
                        break;

                    case 5:
                        System.out.print("Enter Aadhaar Number to search: ");
                        String searchAadhaar = sc.nextLine();
                        service.searchEmployeeByAddhar(searchAadhaar);
                        break;

                    case 6:
                        System.out.print("Enter Employee ID to update phone: ");
                        int id = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter New Phone Number: ");
                        String newPhone = sc.nextLine();
                        service.updatePhoneNumber(id, newPhone);
                        break;

                    case 7:
                        System.out.print("Enter Department Name: ");
                        String deptName = sc.nextLine();
                        service.displayByDepartment(deptName);
                        break;

                    case 8:
                        service.sortEmployeeByJoiningDate();
                        System.out.println("Employees sorted by joining date.");
                        break;

                    case 9:
                        service.sortEmployeeByName();
                        System.out.println("Employees sorted by name.");
                        break;

                    case 10:
                        service.getHigestPaidEmpoyee();
                        break;

                    case 0:
                        exit = true;
                        System.out.println("Exiting... Thank you!");
                        break;

                    default:
                        System.out.println("Invalid choice! Try again.");
                }

            } catch (InvalidPhoneNumberException | InvalidAadhaarException | DuplicateAadhaarException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Unexpected Error: " + e.getMessage());
            }
        }
        
        }catch (Exception e) {
        	System.out.println("\n\nWrong Input !! Unexpected Error: " + e.getMessage());
		}

        sc.close();
    }
}

