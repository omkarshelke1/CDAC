package com.employee.core;

import java.time.LocalDate;

public class FullTimeEmployee extends Employee{

	private double monthlySalary;

	private double performanceBonus;
	
		
	public FullTimeEmployee() {
		super();
	}


	public FullTimeEmployee(String name, LocalDate dateOfJoining, String phoneNumber, String aadhaarNumber,
			DepartmentType department ,double monthlySalary , double performanceBonus) {
		super(name, dateOfJoining, phoneNumber, aadhaarNumber, department , monthlySalary);
		this.monthlySalary = monthlySalary;
		this.performanceBonus = performanceBonus;
	}


	public void calculateSalary() {
		System.out.println("Monthly salary calculated for current Full time employee "+this.getName()+" = "+(monthlySalary+performanceBonus));
	}
	
	public void calculateAnnualBonus() {
		System.out.println("\nCalculate bonus for Full Time Employee = " + ((monthlySalary*12)*0.10));
	}


	@Override
	public String toString() {
		return "FullTimeEmployee [ " +super.toString()+" monthlySalary=" + monthlySalary + ", performanceBonus=" + performanceBonus + "]";
	}
	
	

	
}
