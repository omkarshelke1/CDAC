package com.employee.core;

import java.time.LocalDate;

public class Employee {
	private int empId;

	private String name;

	private LocalDate dateOfJoining;
	
	private String phoneNumber;

	private String aadhaarNumber;

	private DepartmentType department;
	
	private String type;
	
	private double salary;
	
	private static int idGenerator = 0;
	

	public Employee() {
		super();
	}


	public Employee(String aadhaarNumber) {
		super();
		this.aadhaarNumber = aadhaarNumber;
	}
	
	public Employee(String name, LocalDate dateOfJoining, String phoneNumber, String aadhaarNumber,
			DepartmentType department , double salary) {
		super();
		this.empId = ++idGenerator;
		this.name = name;
		this.dateOfJoining = dateOfJoining;
		this.phoneNumber = phoneNumber;
		this.aadhaarNumber = aadhaarNumber;
		this.department = department;
		this.salary = salary;
	}


	
	
	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}


	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getAadhaarNumber() {
		return aadhaarNumber;
	}


	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}


	public DepartmentType getDepartment() {
		return department;
	}


	public void setDepartment(DepartmentType department) {
		this.department = department;
	}


	@Override
	public String toString() {
		return "empId=" + empId + ", name=" + name + ", dateOfJoining=" + dateOfJoining + ", phoneNumber="
				+ phoneNumber + ", aadhaarNumber=" + aadhaarNumber + ", department=" + department + "]";
	}
	
	public void calculateSalary() {
		System.out.println("Not applicable for salary ");
	}
	
	@Override
	public boolean equals(Object o) {
		if(o instanceof Employee) {
			return this.aadhaarNumber.equals(((Employee)o).aadhaarNumber);
		}
		return false;
	}
}
