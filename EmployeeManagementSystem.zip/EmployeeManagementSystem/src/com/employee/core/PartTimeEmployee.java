package com.employee.core;

import java.time.LocalDate;

public class PartTimeEmployee extends Employee{
	private double hourlyRate;

	private int hoursWorked;
	
	

	public PartTimeEmployee() {
		super();
	}


	public PartTimeEmployee(String name, LocalDate dateOfJoining, String phoneNumber, String aadhaarNumber,
			DepartmentType department , double hourlyRate , int hoursWorked) {
		super(name, dateOfJoining, phoneNumber, aadhaarNumber, department , (hourlyRate*hoursWorked));
		this.hourlyRate = hourlyRate;
		this.hoursWorked = hoursWorked;
	}


	public void calculateSalary() {
		System.out.println("\nMonthly salary calculated for current Part time employee = "+(hourlyRate*hoursWorked));
	}

	public void calculateOvertimePay() {
		if(hoursWorked > 160) {
			System.out.println("\nExtra wages for Overtime EMPLOYEE --> "+this.getName()+" "+((hourlyRate*hoursWorked)*0.05));
		}
		else {
			System.out.println("\nExtra wages not applicable for current employee Overtime"+this.getName()+" ");
		}
	}


	@Override
	public String toString() {
		return "PartTimeEmployee [ "+ super.toString() +" hourlyRate=" + hourlyRate + ", hoursWorked=" + hoursWorked + "]";
	}
	
	
}
