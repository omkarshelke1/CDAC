package com.employee.core;

public enum DepartmentType {
	HR, IT, SALES, FINANCE, SUPPORT
}
