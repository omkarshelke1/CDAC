package com.employee.validation;

import java.time.LocalDate;
import java.util.List;

import com.employee.core.DepartmentType;
import com.employee.core.Employee;
import com.employee.core.FullTimeEmployee;
import com.employee.core.PartTimeEmployee;
import com.employee.exception.DuplicateAadhaarException;
import com.employee.exception.InvalidAadhaarException;
import com.employee.exception.InvalidPhoneNumberException;

public class EmployeeValidation {
	public static Employee validateAllImputs(String name, String dateOfJoining, String phoneNumber, String aadhaarNumber,
			String department , String type , double monthlySalary, double performanceBonus, double hourlyRate, int hoursWorked , List<Employee> listOfEmployee) 
					throws InvalidPhoneNumberException, InvalidAadhaarException, DuplicateAadhaarException {
		Employee e;
		validatephoneNumber(phoneNumber);
		validateAddharSyntax(aadhaarNumber);
		validateDuplicateAddhar(aadhaarNumber,listOfEmployee);
		if(type.equals("FULLTIME")) {
			 e = new FullTimeEmployee(name,LocalDate.parse(dateOfJoining),
					phoneNumber,aadhaarNumber,DepartmentType.valueOf(department),monthlySalary,performanceBonus);
		}else {
			 e = new PartTimeEmployee(name,LocalDate.parse(dateOfJoining),
					phoneNumber,aadhaarNumber,DepartmentType.valueOf(department),hourlyRate,hoursWorked);
		}
		return e;
		
	}

	@SuppressWarnings("unlikely-arg-type")
	private static void validateDuplicateAddhar(String aadhaarNumber, List<Employee> listOfEmployee) throws DuplicateAadhaarException {
		Employee e = new Employee(aadhaarNumber);
		if(listOfEmployee.contains(listOfEmployee)) {
			throw new DuplicateAadhaarException("Duplicate addhar number found !!!");
		}
		
	}

	private static void validateAddharSyntax(String aadhaarNumber) throws InvalidAadhaarException {
	    if (!aadhaarNumber.matches("^\\d{12}$")) {
	        throw new InvalidAadhaarException("Invalid aadhar number syntax");
	    }
	}


	private static void validatephoneNumber(String phoneNumber) throws InvalidPhoneNumberException {
		if(!(phoneNumber.matches("^[6-9]\\d{9}$"))) {
			throw new InvalidPhoneNumberException("Invalid phone number syntax first digit must be 6, 7, 8, or 9 with length 10 (Indian mobile numbers)");
		}
	}
}
