package com.employee.service;

import java.time.LocalDate;

import com.employee.core.DepartmentType;
import com.employee.exception.DuplicateAadhaarException;
import com.employee.exception.InvalidAadhaarException;
import com.employee.exception.InvalidPhoneNumberException;

public interface EmployeeService {
	public void addEmployee(String name, String dateOfJoining, String phoneNumber, String aadhaarNumber,
			String department , String type  , double monthlySalary , double performanceBonus , double hourlyRate , int hoursWorked)
					throws InvalidPhoneNumberException, InvalidAadhaarException, DuplicateAadhaarException;
	
	public void deleteEmployeeById(int id);
	
	public void searchEmployeeByAddhar(String addhar);
	
	public void updatePhoneNumber(int id, String phonenumber);
	
	public void displayallEmployee();
	
	public void displayByDepartment(String dept);
	
	public void sortEmployeeByJoiningDate();
	
	public void sortEmployeeByName();
	
	public void getHigestPaidEmpoyee() throws DuplicateAadhaarException;
	
	public void DisplayEmployeeSpecificActions();
}
