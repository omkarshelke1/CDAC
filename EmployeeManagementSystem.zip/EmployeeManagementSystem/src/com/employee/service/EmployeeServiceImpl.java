package com.employee.service;

import com.employee.core.DepartmentType;
import com.employee.core.Employee;
import com.employee.core.FullTimeEmployee;
import com.employee.core.PartTimeEmployee;
import com.employee.exception.DuplicateAadhaarException;
import com.employee.exception.InvalidAadhaarException;
import com.employee.exception.InvalidPhoneNumberException;

import static com.employee.validation.EmployeeValidation.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeServiceImpl implements EmployeeService {
	
	List<Employee> listOfEmployee = new ArrayList<>();

	@Override
	public void addEmployee(String name, String dateOfJoining, String phoneNumber, String aadhaarNumber,
			String department , String type , double monthlySalary, double performanceBonus, double hourlyRate, int hoursWorked) throws InvalidPhoneNumberException, InvalidAadhaarException, DuplicateAadhaarException {
		Employee e  = validateAllImputs(name, dateOfJoining, phoneNumber, aadhaarNumber, department,type,
				monthlySalary, performanceBonus, hourlyRate, hoursWorked , listOfEmployee);
     	listOfEmployee.add(e);
     	System.out.println("Employee added succesfully!!!");
	}
	
	// Concept used : Instance of || downcasting -----   accessing child specific functions 
	
	@Override
	public void DisplayEmployeeSpecificActions() {
		// TODO Auto-generated method stub
		for (Employee employee : listOfEmployee) {
			if(employee instanceof FullTimeEmployee) {
				((FullTimeEmployee) employee).calculateAnnualBonus();
			}else {
				((PartTimeEmployee) employee).calculateOvertimePay();
			}
		}
	}

	@Override
	public void deleteEmployeeById(int id) {
		// TODO Auto-generated method stub
		boolean removed = listOfEmployee.removeIf(emp -> emp.getEmpId() == id);

	    if (!removed) {
	        System.out.println("Employee with ID " + id + " not found!");
	    } else {
	        System.out.println("Employee with ID " + id + " deleted successfully.");
	    }
		
	}

	@Override
	public void searchEmployeeByAddhar(String addhar) {
		// TODO Auto-generated method stub
		listOfEmployee.stream()
		.filter(emp -> emp.getAadhaarNumber().equals(addhar))
		.findFirst()
        .ifPresentOrElse(
            emp -> System.out.println("Employee Found: " + emp),
            () -> System.out.println("No employee found with Aadhaar: " + addhar)
        );
		
	}

	@Override
	public void updatePhoneNumber(int id, String phonenumber) {
		// TODO Auto-generated method stub
		
		//for updating multiple employees and returning a list to make next changes
		
		
//		List<Employee> updated = listOfEmployee.stream()
//		        .filter(emp -> emp.getDepartment().equalsIgnoreCase(department))
//		        .peek(emp -> emp.setPhoneNumber(newPhoneNumber)) // update each employee
//		        .toList();
		
		listOfEmployee.stream()
		.filter(emp -> emp.getEmpId() == id)
		.findFirst()
        .ifPresentOrElse(
            emp -> emp.setPhoneNumber(phonenumber),
            () -> System.out.println("No employee found with phonenumber: " + phonenumber)
        );
	}

	@Override
	public void displayallEmployee() {
		// TODO Auto-generated method stub
		listOfEmployee.forEach(emp -> System.out.println(emp));
		
	}

	@Override
	public void displayByDepartment(String dept) {
		// TODO Auto-generated method stub
		listOfEmployee.stream()
		.filter(emp -> emp.getDepartment() == DepartmentType.valueOf(dept))
		.forEach(emp -> System.out.println(emp));
		
	}

	@Override
	public void sortEmployeeByJoiningDate() {
		// TODO Auto-generated method stub
	    Collections.sort(listOfEmployee,(a,b)-> a.getDateOfJoining().compareTo(b.getDateOfJoining()));
	    listOfEmployee.forEach(emp -> System.out.println(emp));
		
	}

	@Override
	public void sortEmployeeByName() {
		// TODO Auto-generated method stub
		Collections.sort(listOfEmployee,(a,b)-> a.getName().compareTo(b.getName()));
		listOfEmployee.forEach(emp -> System.out.println(emp));
	}

	@Override
	public void getHigestPaidEmpoyee() throws DuplicateAadhaarException {
		// TODO Auto-generated method stub
		 Employee e =  listOfEmployee.stream()
		.max((a,b)-> ((Double)a.getSalary()).compareTo(b.getSalary()))
		.orElseThrow(()-> new DuplicateAadhaarException("No any employee found!!"));
		 
		 System.out.println(e);
		
	}


}
